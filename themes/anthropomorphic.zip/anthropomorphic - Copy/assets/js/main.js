(() => {
  const getScrollPosition = () => ({
    x: window.scrollX || document.documentElement.scrollLeft,
    y: window.scrollY || document.documentElement.scrollTop
  });

  const getRandomColor = () => {
    const r = Math.floor(Math.random() * 256);
    const g = Math.floor(Math.random() * 256);
    const b = Math.floor(Math.random() * 256);

    return `rgb(${r}, ${g}, ${b})`;
  };

  const shouldFlip = () => Math.random() < 0.5;

  const getRandomRotation = () => (Math.random() * 96 - 48).toFixed(2);

  const animateMews = (mews) => {
    mews.forEach((mew, index) => {
      mew.alpha -= 0.016;

      if (mew.alpha <= 0) {
        document.body.removeChild(mew.el);
        mews.splice(index, 1);
      } else {
        mew.y--;
        mew.scale += 0.004;

        const transformStyle = `scale(${mew.scale}) rotate(${mew.rotation}deg)${mew.flipX ? ' scaleX(-1)' : ''}`;

        Object.assign(mew.el.style, {
          left: `${mew.x}px`,
          top: `${mew.y}px`,
          opacity: mew.alpha,
          transform: transformStyle,
          fontSize: `${mew.size}px`,
          color: mew.color,
          zIndex: '100',
          position: 'absolute',
          pointerEvents: 'none'
        });
      }
    });

    requestAnimationFrame(() => animateMews(mews));
  };

  const handleClick = (event, icons, mews) => {
    const randomIcon = icons[Math.floor(Math.random() * icons.length)];
    const mew = document.createElement('div');
    mew.innerHTML = randomIcon;
    mew.className = 'mew';

    const scrollPos = getScrollPosition();
    const posX = event.clientX - 8 + scrollPos.x;
    const posY = event.clientY - 8 + scrollPos.y;
    const flipX = shouldFlip();
    const rotation = getRandomRotation();

    mews.push({
      el: mew,
      x: posX,
      y: posY,
      scale: 1,
      alpha: 1,
      size: 18,
      color: getRandomColor(),
      flipX,
      rotation
    });

    document.body.appendChild(mew);
  };

  const initialize = () => {
    const mews = [];
    const icons = [
      '<i class="fa-solid fa-heart"></i>',
      '<i class="fa-solid fa-paw"></i>',
      '<i class="fa-solid fa-dog"></i>',
      '<i class="fa-solid fa-fish"></i>',
      '<i class="fa-solid fa-dragon"></i>',
      '<i class="fa-solid fa-horse"></i>',
      '<i class="fa-solid fa-dove"></i>',
      '<i class="fa-solid fa-cat"></i>'
    ];

    document.addEventListener('click', (event) => {
      handleClick(event, icons, mews);
    });

    animateMews(mews);
  };

  initialize();
})();

const lightboxEnabled = document.querySelectorAll('.lightbox-enabled');
const lightboxArray = Array.from(lightboxEnabled);
const lastImage = lightboxArray.length - 1;
const lightboxContainer = document.querySelector('.lightbox-container');
const lightboxImage = document.querySelector('.lightbox-image');

const lightboxBtns = document.querySelectorAll('.lightbox-btn');
const lightboxBtnLeft = document.querySelector('#left');
const lightboxBtnRight = document.querySelector('#right');
let activeImage;

const credits = document.querySelector('.p-mobile');

const showLightBox = () => {lightboxContainer.classList.add("active")}
const hideLightBox = () => {lightboxContainer.classList.remove("active")}

const setActiveImage = (image) => {
  lightboxImage.src = image.dataset.imagesrc;
  activeImage = lightboxArray.indexOf(image);
  credits.innerHTML = "   " + image.alt;
}

const transitionSlidesLeft = () => {
  lightboxBtnLeft.focus();
  activeImage === 0 ? setActiveImage(lightboxArray[lastImage]) : setActiveImage(lightboxArray[activeImage - 1]);
}

const transitionSlidesRight = () => {
  lightboxBtnRight.focus();
  activeImage === lastImage ? setActiveImage(lightboxArray[0]) : setActiveImage(lightboxArray[activeImage + 1]);
}

const transitionSlideHandler = (moveItem) => {
  moveItem.includes('left') ? transitionSlidesLeft() : transitionSlidesRight();
}

lightboxEnabled.forEach(image => {
  image.addEventListener('click', (e) => {
    console.log(e.target);
    showLightBox()
    setActiveImage(image);
  })
})

lightboxContainer.addEventListener('click', () => { hideLightBox() })

lightboxBtns.forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    transitionSlideHandler(e.currentTarget.id);
    // console.log(e.currentTarget.id)
  })
})