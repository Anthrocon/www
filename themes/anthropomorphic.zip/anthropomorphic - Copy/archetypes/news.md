---
title: "{{ replace .File.ContentBaseName '-' ' ' | title }}"
author: ""
date: "{{ .Date }}"
draft: false

banner: ""
banner_author: ""
banner_url: ""
---
