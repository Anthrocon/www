---
title: "{{ replace .File.ContentBaseName '-' ' ' | title }}"
date: "{{ .Date }}"
draft: false
weight: 0

banner: ""
banner_author: ""
banner_url: ""
---
